 
This source code is published under the GNU General Public License (GPL) 

The following paper should be cited when using this source code:   

L. Fotio Tiotsop, F. Agboma, G. Van Wallendael, A. Aldahdooh, S. Bosse, L. Janowski, M. Barkowsky, E. Masala, "On the Link Between Subjective Score Prediction and Disagreement of Video Quality Metrics", in IEEE Access, 2021, vol. 9, pp. 152923-152937, ISSN: 2169-3536, DOI: 10.1109/ACCESS.2021.3127395


When using the code for the first time, we recommend running the "Example.m" script in Matlab. This script shows a detailed example (and includes comments) of how this source code can be used. After running the "Example.m" script, you should get a figure similar to Figure 10 in the paper "On the Link Between Subjective Score Prediction and Disagreement of Video Quality Metrics", in IEEE Access, 2021, vol. 9, pp. 152923-152937, ISSN: 2169-3536, DOI: 10.1109/ACCESS.2021.3127395.  If this figure is obtained, the user has everything he/she needs to run this source code.  After this preliminary step, the user must refer to the USE CASE SECTION that explains how to use the code in practice to address each specific problem it was designed for. 


----------- SOURCE CODE COMPONENTS -------------------------------


The source code folder includes the following: 

-HD_videos_training_set.csv. This file contains the Video Quality scores used to compute the coefficients of the third-order polynomial functions that map the video quality measure (VQM) scores to the VMAF scale. If you are interested in 4K videos, you will need to create your own 4K dataset containing your video quality scores.  


-Compute_disagreement_index.m is a Matlab function that takes an array of video quality scores (VQMs) for a given PVS and then outputs the value of the disagreement index. The input of the VQM scores must be provided in the same order as in the HD_videos_training_set.csv


-The MATLAB script "Example.m" implements an example that showcases the effectiveness of the disagreement index in distinguishing between the cases where VQMs are accurate and when they are likely to fail.


-Small_scale_subjective_dataset.csv - A test set, i.e. a small scale subjective annotated dataset on which the accuracy of the disagreement index to distinguish between cases where the VQMs are accurate and not is tested. 


----------- USE CASES ---------------------------------------------


Use case 1: Identifying problematic Processed Video Sequences (PVSs) for VQMs.
           If you want to know if the VQMs can accurately assess its perceptual quality or whether you should rely on a subjective test. 

            
           1) If the PVS was derived from a Full HD content, then this source code must be used by implementing the following steps  
              a) compute the VMAF, PSNR, SSIM, MSSSIM, VIF and XPSNR scores for that PVS; 
              b) put the obtained VQMs scores in a MATLAB array, i.e., VQ=[VMAF, PSNR, SSIM, MSSSIM, VIF, XPSNR];
              c) run the following code on the MATLAB's command line  d= Compute_disagreement_index(VQ);  
              d) if the value of d is greater than 0.6, then it is recommended to evaluate the PVS subjectively. 


          2) If the PVS was not derived from a Full HD content, then: 
             a) prepare a dataset of VQM scores for the PVSs. The VQM on the first column must be VMAF, while the other ones might be any metrics at the user's disposal. We recommend the inclusion of PSNR, SSIM, MSSSIM and VIF; 
             b) give a name (e.g., "My_training_set.csv") to the dataset created in the previous step (step 2a) and save it in the source code folder;
             c) in the MATLAB script Compute_disagreement_index.m  replace "training_set_FullHD.csv" by "My_training_set.csv"; 
             d) prepare a MATLAB array (called VQ) containing the scores of the VQMs in "My_training_set.csv" obtained on the PVS to be analysed;
             e) run the following code on the MATLAB's command line  d= Compute_disagreement_index(VQ);  
             f) if the value of d is greater than 0.6, then it is recommended to evaluate the PVS subjectively. 
  
