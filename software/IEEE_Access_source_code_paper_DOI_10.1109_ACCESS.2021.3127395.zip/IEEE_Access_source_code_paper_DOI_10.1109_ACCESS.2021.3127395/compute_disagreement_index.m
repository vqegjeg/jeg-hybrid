function [disagreement]=compute_disagreement_index(data_VQMs)

% data_VQMs: An array containing VQMs scores, VMAF scores must be on the first colunm.
% disagreement: the disagreement computed for each PVS in the input dataset.


       % reading the training set to fit the coef of the polynonials
         Training_set=readtable('training_set_FullHD.csv','ReadVariableNames',true);
         Training_set=table2array(Training_set);
         
       % setting the VMAF sensitivity
         Delta=7;

         
      %Computing Least square fitting to the VMAF scale weights
         VMAF_fit=zeros(size(data_VQMs));
         number_of_vqm=size(data_VQMs,2);
         VMAF_score=Training_set(:,1);
         for i=1:size(Training_set,2) 
             x=Training_set(:,i);
             vals=(linspace(min(x),max(x),100))';
             C=[x.^3,x.^2,x.^1,x.^0];
             A=-[3*vals.^2,2*vals.^1,vals.^0,zeros(length(vals),1)]; % increasing crve constraint
             b=zeros(length(vals),1);
             p(i,:)=lsqlin(C,VMAF_score,A,b);
         end
         
         % mapping the VQM to the VMAF scale using the computed weights
         for i=1:size(VMAF_fit,2)
              VMAF_fit(:,i)=polyval(p(i,:),data_VQMs(:,i));
         end

        % computing the desagreement of  all VQMs
        disagreement=zeros(size(VMAF_fit,1),1);
        VQMs_couples =nchoosek(1:number_of_vqm,2);

        for i=1:size(VQMs_couples,1)
            couple_of_vqms=VMAF_fit(:,VQMs_couples(i,:));
            disagreement=disagreement+(abs(couple_of_vqms(:,1)-couple_of_vqms(:,2))>Delta);
        end
        disagreement=disagreement/size(VQMs_couples,1);

end 