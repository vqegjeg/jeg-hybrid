clear all;
close all; 

% reading the dataset that includs the MOS values and the VQMs score 
Dataset=readtable('Small_scale_subjective_dataset.csv','ReadVariableNames',true);
VQMs_name={Dataset.Properties.VariableNames{1:(end-1)}};


% computing and adding the disagreement index  to  the dataset
Dataset=table2array(Dataset);
VQM_scores=Dataset(:,1:(end-1)) 
Disagreement_index=compute_disagreement_index(VQM_scores);
Dataset=[Dataset,Disagreement_index]

% fit VQMs to MOS for the RMSE vs disagreement analysis 
MOS=Dataset(:,end-1);
scalled_VQMs_scores=zeros(size(VQM_scores));
for i=1:size(scalled_VQMs_scores,2)
    scalled_VQMs_scores(:,i)=fit_vqm_2_mos(VQM_scores(:,i),MOS);
end

% compute RMSE errors for low disagreement 
RMSE_low_disagreement=zeros(length(VQMs_name),1);
id_low_disagreement= (Disagreement_index<0.2);

scalled_VQMs_score_Low_D=zeros(size(VQM_scores(id_low_disagreement,:)));
for i=1:size(scalled_VQMs_scores,2)
    scalled_VQMs_score_Low_D(:,i)=fit_vqm_2_mos(VQM_scores(id_low_disagreement,i),MOS(id_low_disagreement));
end


for i=1:length(VQMs_name)
    RMSE_low_disagreement(i)=rmse(scalled_VQMs_score_Low_D(:,i),MOS(id_low_disagreement));
end


% compute RMSE for high disagreement 
RMSE_high_disagreement=zeros(length(VQMs_name),1);
id_high_disagreement= (Disagreement_index>0.6);

scalled_VQMs_score_high__D=zeros(size(VQM_scores(id_high_disagreement,:)));
for i=1:size(scalled_VQMs_scores,2)
    scalled_VQMs_score_high_D(:,i)=fit_vqm_2_mos(VQM_scores(id_high_disagreement,i),MOS(id_high_disagreement));
end


for i=1:length(VQMs_name)
    RMSE_high_disagreement(i)=rmse(scalled_VQMs_score_high_D(:,i),MOS(id_high_disagreement));
end

% barplot of the RMSE as function of the Disagreement Index
figure 
set(gcf, 'Position',  [500, 500, 700, 700])
set(0, 'defaultAxesFontSize', 30);
set(0, 'defaultTextFontSize', 30);
set(gca,'FontSize',30);
set(0, 'DefaultLineLineWidth', 4);
bar(categorical(VQMs_name),[RMSE_low_disagreement,RMSE_high_disagreement])
ax=gca;
ax.GridAlpha=1;
grid on; 
box on;
legend({'Low D','High D'});
xlabel('VQMs');
ylabel('RMSE')
yticks([0 .2 .4 .6 .8 1 1.2 1.4])



function [fitted_Val,rmse,coefs]=fit_vqm_2_mos(vqm,mos)
        num_obs=length(vqm);
        fun = @(x) x(1)*(0.5-1./(1+exp(x(2)*(vqm-x(3)))))+x(4)*vqm+x(5) - mos;        
        lb = [-inf,-inf,0,-1,-inf];
        ub = [inf,inf,inf,inf,inf];
        x0 = [1,0,0,100,3];
        x = lsqnonlin(fun,x0,lb,ub)
        fun(x);
        fitted_Val=fun(x)+mos
        rmse=sqrt((1/(num_obs-5))*sum(fun(x).^2))
        coefs=x;
end

function r=rmse(data,estimate)
% Function to calculate root mean square error from a data vector or matrix 
% and the corresponding estimates.
% Usage: r=rmse(data,estimate)
% Note: data and estimates have to be of same size
% Example: r=rmse(randn(100,100),randn(100,100));
% delete records with NaNs in both datasets first
I = ~isnan(data) & ~isnan(estimate); 
data = data(I); estimate = estimate(I);
r=sqrt(sum((data(:)-estimate(:)).^2)/(numel(data)-5));
end
